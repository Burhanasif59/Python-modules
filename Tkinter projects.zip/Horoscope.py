from Tkinter import *
import bs4 as bs
import urllib

#----------------------------------------------------
def aquarius():
        data = urllib.urlopen("https://www.astrology.com/horoscope/daily/aquarius.html").read()
        soup = bs.BeautifulSoup(data,'html.parser')
        text = soup.findAll("div",{"class" : "page-horoscope-text"})
        for paragraph in text:
            final = paragraph.text
            #Canvas for the output of the horoscope
        window = Tk()
        window.geometry("500x300")
         #Canvas
        lab_out = Label(window,text = final,wraplengt = 450,font = ("Ariel",15)).place(x = 10,y = 0)
        window.mainloop()

def pisces():
        data = urllib.urlopen("https://www.astrology.com/horoscope/daily/pisces.html").read()
        soup = bs.BeautifulSoup(data,'html.parser')
        text = soup.findAll("div",{"class" : "page-horoscope-text"})
        for paragraph in text:
                final = paragraph.text
        window = Tk()
        window.geometry("500x300")
         #Canvas
        lab_out = Label(window,text = final,wraplengt = 450,font = ("Ariel",15)).place(x = 10,y = 0)
        window.mainloop()      
           
       
def aries():
    data = urllib.urlopen("https://www.astrology.com/horoscope/daily/aries.html").read()
    soup = bs.BeautifulSoup(data,'html.parser')
    text = soup.findAll("div",{"class" : "page-horoscope-text"})
    for paragraph in text:
        final = paragraph.text
    window = Tk()
    window.geometry("500x300")
         #Canvas
    lab_out = Label(window,text = final,wraplengt = 450,font = ("Ariel",15)).place(x = 10,y = 0)
    window.mainloop()
        
def taurus():
    data = urllib.urlopen("https://www.astrology.com/horoscope/daily/taurus.html").read()
    soup = bs.BeautifulSoup(data,'html.parser')
    text = soup.findAll("div",{"class" : "page-horoscope-text"})
    for paragraph in text:
            final = paragraph.text
    window = Tk()
    window.geometry("500x300")
        #Canvas
    lab_out = Label(window,text = final,wraplengt = 450,font = ("Ariel",15)).place(x = 10,y = 0)
        
def gemini():
    data = urllib.urlopen("https://www.astrology.com/horoscope/daily/gemini.html").read()
    soup = bs.BeautifulSoup(data,'html.parser')
    text = soup.findAll("div",{"class" : "page-horoscope-text"})
    for paragraph in text:
            final = paragraph.text
    window = Tk()
    window.geometry("500x300")
        #Canvas
    lab_out = Label(window,text = final,wraplengt = 450,font = ("Ariel",15)).place(x = 10,y = 0)

def cancer():
    data = urllib.urlopen("https://www.astrology.com/horoscope/daily/cancer.html").read()
    soup = bs.BeautifulSoup(data,'html.parser')
    text = soup.findAll("div",{"class" : "page-horoscope-text"})
    for paragraph in text:
            final = paragraph.text
    window = Tk()
    window.geometry("500x300")
        #Canvas
    lab_out = Label(window,text = final,wraplengt = 450,font = ("Ariel",15)).place(x = 10,y = 0)
        
def leo():
    data = urllib.urlopen("https://www.astrology.com/horoscope/daily/leo.html").read()
    soup = bs.BeautifulSoup(data,'html.parser')
    text = soup.findAll("div",{"class" : "page-horoscope-text"})
    for paragraph in text:
            final = paragraph.text
    window = Tk()
    window.geometry("500x300")
         #Canvas
    lab_out = Label(window,text = final,wraplengt = 450,font = ("Ariel",15)).place(x = 10,y = 0)

def virgo():
    data = urllib.urlopen("https://www.astrology.com/horoscope/daily/virgo.html").read()
    soup = bs.BeautifulSoup(data,'html.parser')
    text = soup.findAll("div",{"class" : "page-horoscope-text"})
    for paragraph in text:
            final = paragraph.text
    window = Tk()
    window.geometry("500x300")
    #Canvas
    lab_out = Label(window,text = final,wraplengt = 450,font = ("Ariel",15)).place(x = 10,y = 0)
def libra():
    data = urllib.urlopen("https://www.astrology.com/horoscope/daily/libra.html").read()
    soup = bs.BeautifulSoup(data,'html.parser')
    text = soup.findAll("div",{"class" : "page-horoscope-text"})
    for paragraph in text:
            final = paragraph.text
    window = Tk()
    window.geometry("500x300")
         #Canvas
    lab_out = Label(window,text = final,wraplengt = 450,font = ("Ariel",15)).place(x = 10,y = 0)   

def scorpio():
    data = urllib.urlopen("https://www.astrology.com/horoscope/daily/scorpio.html").read()
    soup = bs.BeautifulSoup(data,'html.parser')
    text = soup.findAll("div",{"class" : "page-horoscope-text"})
    for paragraph in text:
            final = paragraph.text
    window = Tk()
    window.geometry("500x300")
         #Canvas
    lab_out = Label(window,text = final,wraplengt = 450,font = ("Ariel",15)).place(x = 10,y = 0)
        
def sagittarius():
    data = urllib.urlopen("https://www.astrology.com/horoscope/daily/sagittarius.html").read()
    soup = bs.BeautifulSoup(data,'html.parser')
    text = soup.findAll("div",{"class" : "page-horoscope-text"})
    for paragraph in text:
            final = paragraph.text
    window = Tk()
    window.geometry("500x300")
        #Canvas
    lab_out = Label(window,text = final,wraplengt = 450,font = ("Ariel",15)).place(x = 10,y = 0)
def capricorn():
    data = urllib.urlopen("https://www.astrology.com/horoscope/daily/capricorn.html").read()
    soup = bs.BeautifulSoup(data,'html.parser')
    text = soup.findAll("div",{"class" : "page-horoscope-text"})
    for paragraph in text:
            final = paragraph.text
    window = Tk()
    window.geometry("500x300")
 #Canvas
    lab_out = Label(window,text = final,wraplengt = 450,font = ("Ariel",15)).place(x = 10,y = 0)
#-----------------------------------------------------
root = Tk()
#The window title and size and not making it resizable
root.title("Horoscope")
root.geometry("250x250")
root.resizable(width = False,height = False)
#Labels
#------------------------------------------------------
label_intro = Label(root,text = "Pick your zodiac sign",font = ("Ariel",15))
#------------------------------------------------------
#Buttons
button_aquarius = Button(root,text = "Aquarius",command = aquarius,font = ("Ariel",10))
button_pisces = Button(root,text = "Pisces",command = pisces,font = ("Ariel",10))
button_aries = Button(root,text = "Aries",command = aries,font = ("Ariel",10))
button_taurus = Button(root,text = "Taurus",command = taurus,font = ("Ariel",10))
button_gemini = Button(root,text = "Gemini",command = gemini,font = ("Ariel",10))
button_cancer = Button(root,text = "Cancer",command = cancer,font = ("Ariel",10))
button_leo = Button(root,text = "Leo",command = leo,font = ("Ariel",10))
button_virgo = Button(root,text = "Virgo",command = virgo,font = ("Ariel",10))
button_libra = Button(root,text = "Libra",command = libra,font = ("Ariel",10))
button_scorpio = Button(root,text = "Scorpio",command = scorpio,font = ("Ariel",10))
button_sagittarius = Button(root,text = "Sagittarius",command = sagittarius,font = ("Ariel",9))
button_capricorn = Button(root,text = "Capricorn",command = capricorn,font = ("Ariel",10))
#--------------------------------------------------------
#Placing the Labels
label_intro.place(x = 27,y = 0)
#Placing the buttons
button_aquarius.place(x = 5,y = 50,width = 62,height = 32)
button_pisces.place(x = 95,y = 50,width = 62,height = 32)
button_aries.place(x = 186,y = 50,width = 62,height = 32)
button_taurus.place(x = 5,y = 100,width = 62,height = 32)
button_gemini.place(x = 95,y = 100,width = 62,height = 32)
button_cancer.place(x = 186,y = 100,width = 62,height = 32)
button_leo.place(x = 5,y = 150,width = 62,height = 32)
button_virgo.place(x = 95,y = 150,width = 62,height = 32)
button_libra.place(x = 186,y = 150,width = 62,height = 32)
button_scorpio.place(x = 5,y = 200,width = 62,height = 32)
button_sagittarius.place(x = 95,y = 200,width = 64,height = 32)
button_capricorn.place(x = 186,y = 200,width = 62,height = 32)
root.mainloop()
#-----------------------------------------------------------

