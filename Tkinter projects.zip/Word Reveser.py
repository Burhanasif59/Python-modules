from Tkinter import *

def changer(event):
    global ent_val
    x = ent_val.get()
    x_x = x[::-1]
    lab_ans_val.config(text = x_x,fg = "red" )


#The main window

root = Tk()

#Title of the window
root.title("Word reverser")

#Root size
root.geometry("265x220")

#Making the root not resizable
root.resizable(width = False,height = False)


#The Labels
lab_val = Label(root,text = "Word:",font = ("Ariel",20))
lab_ans = Label(root,text = "Reversed:",font = ("Ariel",20))
lab_ans_val = Label(root,text = "",font = ("Ariel",20))
#Placing the labels
lab_val.place(x = 10,y = 30)
lab_ans.place(x = 10,y = 100)
lab_ans_val.place(x = 135,y = 100)
#The entries
ent_val = Entry(root)
ent_val.place(x = 90,y = 42)
#Binding the entry
ent_val.bind("<Return>",changer)

root.mainloop()
