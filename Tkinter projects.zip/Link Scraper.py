#Web Scraper
#Importing the modules
from Tkinter import*
import urllib
import bs4 as bs
#------------------------------------------------------------------------------
#The main window
root = Tk()
#The Scraping function
def scraper(event):
    link = ent_link.get()
    data = urllib.urlopen(link)
    soup = bs.BeautifulSoup(data,"html.parser")
    for link in soup.find_all("a"):
       print link.get("href")

    
#------------------------------------------------------------------------------
#Title,size and not making the window resizable
root.title("Link Scraper")
root.geometry("300x200")
root.resizable(width = False,height = False)
#------------------------------------------------------------------------------
#Labels
lab_intro = Label(root,text = "Link Scraper",font = ("Arial",20))
lab_ent = Label(root,text = "Please enter the link of the webpage you want to",font = ("Arial",10),)
lab_ent_rem = Label(root,text = "scrape:",font = ("Arial",10))
#------------------------------------------------------------------------------
#entries
ent_link = Entry(root, exportselection=0)
#------------------------------------------------------------------------------
#placing the labels
lab_intro.place(x = 70,y = 0)
lab_ent.place(x = 0, y = 50)
lab_ent_rem.place(x = 0,y = 72)
#------------------------------------------------------------------------------
#Placing and binding the entries
ent_link.place(x = 50,y = 75)
ent_link.bind("<Return>",scraper)
#------------------------------------------------------------------------------
root.mainloop()
