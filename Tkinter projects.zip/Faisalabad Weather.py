#importing modules
from Tkinter import *
import urllib
import bs4 as bs
#--------------------------------------------------------------------------------------------------------------------------------------------

#The main window
root = Tk()
#--------------------------------------------------------------------------------------------------------------------------------------------
#Url Data
data = urllib.urlopen("https://www.yahoo.com/news/weather/pakistan/punjab/faisalabad-2211574")
soup = bs.BeautifulSoup(data,"html.parser")
#--------------------------------------------------------------------------------------------------------------------------------------------
#The weather data
Faisalabad = soup.find("h1",class_="city Fz(2em)--sm Fz(3.7em)--lg Fz(3.3em) Fw(n) M(0) Trsdu(.3s) desktop_Lh(1) smartphone_Lh(1)").get_text()
Pakistan = soup.find("div",class_="Fz(1.2em)--sm Fz(2em)--lg Fz(1.5em) Fw(200) country Trsdu(.3s) Lh(2.5)").get_text()
weather = soup.find("span",class_="description Va(m) Px(2px) Fz(1.3em)--sm Fz(1.6em)").get_text()
degree = soup.find("span",class_="Va(t)").get_text()
#--------------------------------------------------------------------------------------------------------------------------------------------
#Size,title and not making the window resizable
root.title("Faisalabad Weather")
root.geometry("250x250")
root.resizable(width = False,height = False)
#--------------------------------------------------------------------------------------------------------------------------------------------
#The Labels
lab_intro = Label(root,text = "Weather",font = ("Arial",20))
lab_Faisalabad = Label(root,text = Faisalabad,font = ("Arial",20))
lab_Pakistan = Label(root,text = Pakistan,font = ("Arial",20))
lab_weather = Label(root,text = weather,font = ("Arial",20))
lab_degree = Label(root,text = degree,font = ("Arial",20))
lab_f = Label(root,text = "F",font = ("Arial",20))
lab_o = Label(root,text = "o",font = ("Arial",10))
#--------------------------------------------------------------------------------------------------------------------------------------------
#Placing the labels
lab_intro.place(x = 70,y = 0)
lab_Faisalabad.place(x = 0,y = 40)
lab_Pakistan.place(x = 0,y = 90)
lab_weather.place(x = 0,y = 140)
lab_degree.place(x = 0, y = 190)
lab_f.place(x = 55,y = 190)
lab_o.place(x = 45,y = 187)

root.mainloop()
