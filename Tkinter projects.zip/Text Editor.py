#Importing the modules
from Tkinter import *
import tkFileDialog as fd
import ScrolledText
import pickle
import random
#----------------------------------------------------------------------------
#The main window
root = Tk()

print "my name is \bpaul"

#----------------------------------------------------------------------------
#The functions
def Open():
    global textpad
    root_filename = fd.askopenfilename()
    f = open(root_filename,"r+")
    text = f.read()
    print text
    
def Save():
    global textPad
    t = textPad.get("1.0","end-1c")
    root.filename = fd.asksaveasfilename(filetypes = (("jpeg files","*.jpg")))
    file1 = open(root.filename,"w+")
    file1.write(t)
    file1.close()
    
def Quit():
    root.destroy()
    quit()
#----------------------------------------------------------------------------
#The drop down menus
menu = Menu(root)
root.config(menu = menu)
subMenu = Menu(menu,tearoff = 0)
menu.add_cascade(label = "File",menu = subMenu)
subMenu.add_command(label = "Open",command = Open)
subMenu.add_command(label = "Save",command = Save)
subMenu.add_command(label = "Exit",command = Quit)
textpad.insert("\bhello")
#----------------------------------------------------------------------------
textPad = ScrolledText.ScrolledText(root)
textPad.pack(fill = BOTH)
#The place where text will be written and displaying it on the window
root.mainloop()
