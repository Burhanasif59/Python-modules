#Currency rates
#importing the modules
import urllib
import bs4 as bs
import bleach
from Tkinter import * 
#getting the data

data = urllib.urlopen("http://www.forex.com.pk/")
soup = bs.BeautifulSoup(data,"html.parser")

#The main table
tables = soup.find_all("table")[11]



#The australian dollar
table_rows = tables.find_all("tr")[2]
td_buying_australian = table_rows.find_all("td")[1]
td_selling_australian = table_rows.find_all("td")[2]
td_buying_finish = bleach.clean(td_buying_australian,tags = [],strip = True)
td_selling_finish = bleach.clean(td_selling_australian,tags = [],strip = True)
#the canadian dollar
table_rows = tables.find_all("tr")[3]
td_buying_canadian = table_rows.find_all("td")[1]
td_selling_canadian = table_rows.find_all("td")[2]
td_1_buying_finish = bleach.clean(td_buying_canadian,tags = [],strip = True)
td_1_selling_finish = bleach.clean(td_selling_canadian,tags = [],strip = True)
#the chinise yuan
table_rows = tables.find_all("tr")[4]
td_buying_china= table_rows.find_all("td")[1]
td_selling_china = table_rows.find_all("td")[2]
td_2_buying_finish = bleach.clean(td_buying_china,tags = [],strip = True)
td_2_selling_finish = bleach.clean(td_selling_china,tags = [],strip = True)
#the euro 
table_rows = tables.find_all("tr")[5]
td_buying_euro= table_rows.find_all("td")[1]
td_selling_euro = table_rows.find_all("td")[2]
td_3_buying_finish = bleach.clean(td_buying_euro,tags = [],strip = True)
td_3_selling_finish = bleach.clean(td_selling_euro,tags = [],strip = True)
#the japanese yen
table_rows = tables.find_all("tr")[6]
td_buying_japanese= table_rows.find_all("td")[1]
td_selling_japanese = table_rows.find_all("td")[2]
td_4_buying_finish = bleach.clean(td_buying_japanese,tags = [],strip = True)
td_4_selling_finish = bleach.clean(td_selling_japanese,tags = [],strip = True)
#the Saudi riyal
table_rows = tables.find_all("tr")[7]
td_buying_saudi= table_rows.find_all("td")[1]
td_selling_saudi = table_rows.find_all("td")[2]
td_5_buying_finish = bleach.clean(td_buying_saudi,tags = [],strip = True)
td_5_selling_finish = bleach.clean(td_selling_saudi,tags = [],strip = True)
#the uae dirham
table_rows = tables.find_all("tr")[8]
td_buying_uae= table_rows.find_all("td")[1]
td_selling_uae = table_rows.find_all("td")[2]
td_6_buying_finish = bleach.clean(td_buying_uae,tags = [],strip = True)
td_6_selling_finish = bleach.clean(td_selling_uae,tags = [],strip = True)
#the uk pound
table_rows = tables.find_all("tr")[9]
td_buying_uk= table_rows.find_all("td")[1]
td_selling_uk = table_rows.find_all("td")[2]
td_7_buying_finish = bleach.clean(td_buying_uk,tags = [],strip = True)
td_7_selling_finish = bleach.clean(td_selling_uk,tags = [],strip = True)
#the us dollar
table_rows = tables.find_all("tr")[10]
td_buying_us= table_rows.find_all("td")[1]
td_selling_us = table_rows.find_all("td")[2]
td_8_buying_finish = bleach.clean(td_buying_us,tags = [],strip = True)
td_8_selling_finish = bleach.clean(td_selling_us,tags = [],strip = True)
#the main window

lst23 = []

for element in td_buying_finish[0:10]:
    x = str(element)
    if x == "0" or x == "1" or x == "2" or x == "3" or x == "4" or x == "5" or x == "6" or x == "7" or x == "8" or x == "9" or x == "10" or x == ".":
        lst23.append(x)
td_buying_finish = ''.join(map(str, lst23))

lst23 = []

for element in td_selling_finish[0:10]:
    x = str(element)
    if x == "0" or x == "1" or x == "2" or x == "3" or x == "4" or x == "5" or x == "6" or x == "7" or x == "8" or x == "9" or x == "10" or x == ".":
        lst23.append(x)
td_selling_finish = ''.join(map(str, lst23))

lst23 = []
for element in td_1_buying_finish[0:10]:
    x = str(element)
    if x == "0" or x == "1" or x == "2" or x == "3" or x == "4" or x == "5" or x == "6" or x == "7" or x == "8" or x == "9" or x == "10" or x == ".":
        lst23.append(x)
td_1_buying_finish = ''.join(map(str, lst23))

lst23 = []
for element in td_1_selling_finish[0:10]:
    x = str(element)
    if x == "0" or x == "1" or x == "2" or x == "3" or x == "4" or x == "5" or x == "6" or x == "7" or x == "8" or x == "9" or x == "10" or x == ".":
        lst23.append(x)
td_1_selling_finish = ''.join(map(str, lst23))

lst23 = []
for element in td_2_buying_finish[0:10]:
    x = str(element)
    if x == "0" or x == "1" or x == "2" or x == "3" or x == "4" or x == "5" or x == "6" or x == "7" or x == "8" or x == "9" or x == "10" or x == ".":
        lst23.append(x)
td_2_buying_finish = ''.join(map(str, lst23))

lst23 = []
for element in td_2_selling_finish[0:10]:
    x = str(element)
    if x == "0" or x == "1" or x == "2" or x == "3" or x == "4" or x == "5" or x == "6" or x == "7" or x == "8" or x == "9" or x == "10" or x == ".":
        lst23.append(x)
td_2_selling_finish = ''.join(map(str, lst23))

lst23 = []
for element in td_3_buying_finish[0:10]:
    x = str(element)
    if x == "0" or x == "1" or x == "2" or x == "3" or x == "4" or x == "5" or x == "6" or x == "7" or x == "8" or x == "9" or x == "10" or x == ".":
        lst23.append(x)
td_3_buying_finish = ''.join(map(str, lst23))


lst23 = []
for element in td_3_selling_finish[0:10]:
    x = str(element)
    if x == "0" or x == "1" or x == "2" or x == "3" or x == "4" or x == "5" or x == "6" or x == "7" or x == "8" or x == "9" or x == "10" or x == ".":
        lst23.append(x)
td_3_selling_finish = ''.join(map(str, lst23))

lst23 = []
for element in td_4_buying_finish[0:10]:
    x = str(element)
    if x == "0" or x == "1" or x == "2" or x == "3" or x == "4" or x == "5" or x == "6" or x == "7" or x == "8" or x == "9" or x == "10" or x == ".":
        lst23.append(x)
td_4_buying_finish = ''.join(map(str, lst23))

lst23 = []
for element in td_4_selling_finish[0:10]:
    x = str(element)
    if x == "0" or x == "1" or x == "2" or x == "3" or x == "4" or x == "5" or x == "6" or x == "7" or x == "8" or x == "9" or x == "10" or x == ".":
        lst23.append(x)
td_4_selling_finish = ''.join(map(str, lst23))

lst23 = []
for element in td_5_buying_finish[0:10]:
    x = str(element)
    if x == "0" or x == "1" or x == "2" or x == "3" or x == "4" or x == "5" or x == "6" or x == "7" or x == "8" or x == "9" or x == "10" or x == ".":
        lst23.append(x)
td_5_buying_finish = ''.join(map(str, lst23))

lst23 = []
for element in td_5_selling_finish[0:10]:
    x = str(element)
    if x == "0" or x == "1" or x == "2" or x == "3" or x == "4" or x == "5" or x == "6" or x == "7" or x == "8" or x == "9" or x == "10" or x == ".":
        lst23.append(x)
td_5_selling_finish = ''.join(map(str, lst23))

lst23 = []
for element in td_6_buying_finish[0:10]:
    x = str(element)
    if x == "0" or x == "1" or x == "2" or x == "3" or x == "4" or x == "5" or x == "6" or x == "7" or x == "8" or x == "9" or x == "10" or x == ".":
        lst23.append(x)
td_6_buying_finish = ''.join(map(str, lst23))

lst23 = []
for element in td_6_selling_finish[0:10]:
    x = str(element)
    if x == "0" or x == "1" or x == "2" or x == "3" or x == "4" or x == "5" or x == "6" or x == "7" or x == "8" or x == "9" or x == "10" or x == ".":
        lst23.append(x)
td_6_selling_finish = ''.join(map(str, lst23))

lst23 = []
for element in td_8_selling_finish[0:10]:
    x = str(element)
    if x == "0" or x == "1" or x == "2" or x == "3" or x == "4" or x == "5" or x == "6" or x == "7" or x == "8" or x == "9" or x == "10" or x == ".":
        lst23.append(x)
td_8_selling_finish = ''.join(map(str, lst23))

lst23 = []
for element in td_7_buying_finish[0:10]:
    x = str(element)
    if x == "0" or x == "1" or x == "2" or x == "3" or x == "4" or x == "5" or x == "6" or x == "7" or x == "8" or x == "9" or x == "10" or x == ".":
        lst23.append(x)
td_7_buying_finish = ''.join(map(str, lst23))

lst23 = []
for element in td_7_selling_finish[0:10]:
    x = str(element)
    if x == "0" or x == "1" or x == "2" or x == "3" or x == "4" or x == "5" or x == "6" or x == "7" or x == "8" or x == "9" or x == "10" or x == ".":
        lst23.append(x)
td_7_selling_finish = ''.join(map(str, lst23))

lst23 = []
for element in td_8_buying_finish[0:10]:
    x = str(element)
    if x == "0" or x == "1" or x == "2" or x == "3" or x == "4" or x == "5" or x == "6" or x == "7" or x == "8" or x == "9" or x == "10" or x == ".":
        lst23.append(x)
td_8_buying_finish = ''.join(map(str, lst23))




    

root = Tk()



#The main labels
lab_currency = Label(text = "Currency",font = ("Arial",20))
lab_buying = Label(text = "Buying",font = ("Arial",20))
lab_selling= Label(text = "Selling",font = ("Arial",20))
#The australian labels
lab_australian_intro = Label(text = "Australian Dollar",font = ("Arial",13))
lab_australian_buying = Label(text = td_buying_finish,font = ("Arial",15))
lab_australian_selling = Label(text = td_selling_finish,font = ("Arial",15))
#The canadian labels
lab_canadian_intro = Label(text = "Canadian Dollar",font = ("Arial",13))
lab_canadian_buying = Label(text = td_1_buying_finish,font = ("Arial",15))
lab_canadian_selling = Label(text = td_1_selling_finish,font = ("Arial",15))
#The chinise labels
lab_china_intro = Label(text = "China Yuan",font = ("Arial",13))
lab_china_buying = Label(text = td_2_buying_finish,font = ("Arial",15))
lab_china_selling = Label(text = td_2_selling_finish,font = ("Arial",15))
#the euro
lab_euro_intro = Label(text = "Euro",font = ("Arial",13))
lab_euro_buying = Label(text = td_3_buying_finish,font = ("Arial",15))
lab_euro_selling = Label(text = td_3_selling_finish,font = ("Arial",15))
#the japanese yen
lab_japanese_intro = Label(text = "Japanese Yen",font = ("Arial",13))
lab_japanese_buying = Label(text = td_4_buying_finish,font = ("Arial",15))
lab_japanese_selling = Label(text = td_4_selling_finish,font = ("Arial",15))
#the saudi riyal
lab_saudi_intro = Label(text = "Saudi Riyal",font = ("Arial",13))
lab_saudi_buying = Label(text = td_5_buying_finish,font = ("Arial",15))
lab_saudi_selling = Label(text = td_5_selling_finish,font = ("Arial",15))
#the uae dirham
lab_uae_intro = Label(text = "U.A.E Dirham",font = ("Arial",13))
lab_uae_buying = Label(text = td_6_buying_finish,font = ("Arial",15))
lab_uae_selling = Label(text = td_6_selling_finish,font = ("Arial",15))
#the uk pound
lab_uk_intro = Label(text = "UK Pound",font = ("Arial",13))
lab_uk_buying = Label(text = td_7_buying_finish,font = ("Arial",15))
lab_uk_selling = Label(text = td_7_selling_finish,font = ("Arial",15))
#the us dollar
lab_us_intro = Label(text = "US Dollar",font = ("Arial",13))
lab_us_buying = Label(text = td_8_buying_finish,font = ("Arial",15))
lab_us_selling = Label(text = td_8_selling_finish,font = ("Arial",15))


#Placing the labels
lab_currency.place(x = 20 ,y = 10)
lab_buying.place(x = 210 ,y = 10)
lab_selling.place(x = 380 ,y = 10)
lab_australian_intro.place(x = 20,y = 60)
lab_canadian_intro.place(x = 20,y = 110)
lab_china_intro.place(x = 20,y = 160)
lab_euro_intro.place(x = 20,y = 210)
lab_japanese_intro.place(x = 20,y = 260)
lab_saudi_intro.place(x = 20,y = 310)
lab_uae_intro.place(x = 20,y = 360)
lab_uk_intro.place(x = 20,y = 410)
lab_us_intro.place(x = 20,y = 460)
lab_australian_buying.place(x = 210,y = 60)
lab_australian_selling.place(x = 380,y = 60)
lab_canadian_buying.place(x = 210,y = 110)
lab_canadian_selling.place(x = 380,y = 110)
lab_china_buying.place(x = 210,y = 160)
lab_china_selling.place(x = 380,y = 160)
lab_euro_buying.place(x = 210,y = 210)
lab_euro_selling.place(x = 380,y = 210)
lab_japanese_buying.place(x = 210,y = 260)
lab_japanese_selling.place(x = 380,y = 260)
lab_saudi_buying.place(x = 210,y = 310)
lab_saudi_selling.place(x = 380,y = 310)
lab_uae_buying.place(x = 210,y = 360)
lab_uae_selling.place(x = 380,y = 360)
lab_uk_buying.place(x = 210,y = 410)
lab_uk_selling.place(x = 380,y = 410)
lab_us_buying.place(x = 210,y = 460)
lab_us_selling.place(x = 380,y = 460)




root.geometry("500x500")
root.resizable(width = False,height = False)
root.title("Currency Rates")

root.mainloop()
