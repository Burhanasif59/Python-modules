from Tkinter import *
from math import *
import time

answer = 0
 

def main():
    root =Tk()

    #title of the window
    root.title("Temperature converter")
    
    root.geometry("500x100+5+5")
    root.resizable(width=False, height=False)
    #The Top Frame
    TopFrame = Frame(root,width = 300,height = 300)
    TopFrame.pack()

    #The Bottom Frame
    BottomFrame = Frame(root,width = 300,height = 300)
    BottomFrame.pack(side = "bottom")

    #The introduction Label
    lab_intro = Label(TopFrame,text = "Welcome to the temperature converter",font = ("Ariel",20))
    lab_intro.pack()

    #the run button
    but_run = Button(BottomFrame,text = "Press me to go to the converter",font = ("Ariel",13))
    but_run.pack(side = "bottom")
    but_run.bind("<Button-1>",play)
    
    
    root.mainloop()
#------------------------------------------------------------------------------------------------



    

def play(event):
    root = Tk()

    def F(en):
        global answer
        try:
            c_val = int(ent_c.get()) 
            answer = c_val * 9/5 + 32
            label_ans_val.config(text = answer)
        except ValueError:
            pass
        



    def C(en):
        global answer
        try:
            f_val = int(ent_f.get()) 
            answer = (f_val - 32) * 5/9
            label_ans_val.config(text = answer)
        except ValueError:
            pass

    #Not allowing the resizing of the root
    root.resizable(width = False,height = False)

    #title of the window
    root.title("Temperature converter")

    #root size
    root.geometry("176x100")
     
    
    # The entires
    ent_c = Entry(root)
    ent_f = Entry(root)
    #Placing the entries in the frame
    ent_c.place(x = 55,y = 0)
    ent_f.place(x = 55,y = 20)

   
         


    ent_c.bind("<Return>",F)
    ent_f.bind("<Return>",C)

    #The Labels and their placement
    label_c = Label(root,text = "Celsius").place(x = 10,y=0)
    label_f = Label(root,text = "Fahrenheit").place(x = 0,y=20)
    label_ans = Label(root,text = "Answer = " ,font = ("Ariel",20)).place(x=10,y=50)
    label_ans_val = Label(root,text = "0" ,font = (80))
    label_ans_val.place(x = 130,y = 58)
    
    
   
    
    

    
    

    root.mainloop()


main()
