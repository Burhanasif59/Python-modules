#Gold rates
import urllib
import bs4 as bs
import bleach

data = urllib.urlopen("http://www.forex.pk/bullion-rates.php")
soup = bs.BeautifulSoup(data,"html.parser")
table = soup.find_all("table")[15]
print bleach.clean(table,tags = [],strip = True)
