import urllib
import bs4 as bs
from time import sleep
from Tkinter import *


def checker():
    lab_min.config(text = time1)
    lab_sec.config(text = time2)
    root.after(1,checker)





root = Tk()
root.geometry("300x230")
root.resizable(width = False,height = False)
data = urllib.urlopen("https://www.timeanddate.com/time/international-atomic-time.html")
soup = bs.BeautifulSoup(data,"html.parser")
date = soup.find("p",class_="ctm-date").get_text()
time1 = soup.find("span",class_="ctm-hrmn").get_text()
time2 = soup.find("span",class_="ctm-sec").get_text()
lab_intro = Label(root,text = "Atomic Time",font = ("Arial",20))
lab_min = Label(root,text = time1,font = ("Arial",20))
lab_sec = Label(root,text = time2,font = ("Arial",20))
lab_date = Label(root,text = date)
lab_colon = Label(root,text = ":",font = ("Arial",20))
lab_date = Label(root,text = date,font = ("Arial",20))
lab_min.place(x = 80,y = 80)
lab_colon.place(x = 150,y = 78)
lab_sec.place(x = 160,y = 80)
lab_intro.place(x = 70,y = 0)
lab_date.place(x = 0,y = 160)
root.after(1,checker)
root.mainloop()


    

  
    




