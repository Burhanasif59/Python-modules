#Text editor
from Tkinter import *
import tkFileDialog as fd
import ScrolledText
import tkSimpleDialog as simpledialog
import tkFont

title = "Textpad"
FS = 10
FF = "Arial"



def Title():
    line = textPad.get('1.0', END).splitlines()
    for elements in line[0]:
        if len(line[0]) <= 1:
            titlePrompt = simpledialog.askstring("Title","Please enter your title")
            root.title(titlePrompt)
            textPad.insert(END,titlePrompt)
        else:
            root.title(line[0])



def Open():
    root.filename = fd.askopenfilename(filetypes = (("textfiles","*.txt"),("All files","*.*")))
    file1 = open(root.filename,"r+")
    for lines in file1.readlines():
        textPad.insert(END,lines)

def Save():
    global textPad
    t = textPad.get("1.0","end-1c")
    root.filename = fd.asksaveasfilename(initialdir = "/",title = "Select file",filetypes = (("text files","*.txt"),("all files","*.*")))
    file1 = open(root.filename,"w+")
    file1.write(t)
    file1.close()

def Quit():
    root.destroy()
    quit()


def changeFontSize2():
    try:
        textPad.tag_add("btArial2", "sel.first", "sel.last")
        textPad.tag_configure(fonts["btArial2"].configure(size = 2))
    except:
        pass
       
def changeFontSize6():
    try:
        textPad.tag_add("btArial6", "sel.first", "sel.last")
        textPad.tag_configure(fonts["btArial6"].configure(size = 6))
    except:
        pass

def changeFontSize10():
    try:  
        textPad.tag_add("btArial10", "sel.first", "sel.last")
        textPad.tag_configure(fonts["btArial10"].configure(size = 10))
    except:
        pass

def changeFontSize14():
    try:
        textPad.tag_add("btArial14", "sel.first", "sel.last")
        textPad.tag_configure(fonts["btArial14"].configure(size = 14))
    except:
        pass

def changeFontSize20():
    try:
        textPad.tag_add("btArial2", "sel.first", "sel.last")
        textPad.tag_configure(fonts["btArial20"].configure(size = 20))
    except:
        pass

def changeFontSize24():
    try:
        textPad.tag_add("btArial24", "sel.first", "sel.last")
        textPad.tag_configure(fonts["btArial24"].configure(size = 24))
    except:
        pass

def changeFontSize30():
    try:
        textPad.tag_add("btArial30", "sel.first", "sel.last")
        textPad.tag_configure(fonts["btArial30"].configure(size = 30))
    except:
        pass



root = Tk()

#fonts

fonts = {"default" :tkFont.Font(family="Arial", size=10),
                "btArial2" : tkFont.Font(family = "Arial",size = 2),
                 "btArial6" : tkFont.Font(family = "Arial",size = 6),
                 "btArial10" : tkFont.Font(family = "Arial",size = 10),
                 "btArial14" : tkFont.Font(family = "Arial",size = 14),
                 "btArial20" : tkFont.Font(family = "Arial",size = 20),
                 "btArial24" : tkFont.Font(family = "Arial",size = 24),
                 "btArial30" : tkFont.Font(family = "Arial",size = 30)
        

    }

#The textpad text
textPad = ScrolledText.ScrolledText(root,width = 200,height = 50)
textPad.configure(font=fonts["default"])
textPad.tag_configure("btArial2", font=fonts["btArial2"])
textPad.tag_configure("btArial6", font=fonts["btArial6"])
textPad.tag_configure("btArial10", font=fonts["btArial10"])
textPad.tag_configure("btArial14", font=fonts["btArial14"])
textPad.tag_configure("btArial20", font=fonts["btArial20"])
textPad.tag_configure("btArial24", font=fonts["btArial24"])
textPad.tag_configure("btArial30", font=fonts["btArial30"])



textPad.pack(expand = True,fill = "both")



    
#-------------------------------------------------------------
#root title
root.title(title)
#-------------------------------------------------------------
#menus
menu = Menu(root)
editMenu = Menu(root,tearoff = 0)
editMenu2 = Menu(root,tearoff = 0)
root.config(menu = menu)
subMenu = Menu(menu,tearoff = 0)
menu.add_cascade(label = "File",menu = subMenu)
subMenu.add_command(label = "Open",command = Open)
subMenu.add_command(label = "Save",command = Save)
subMenu.add_command(label = "Exit",command = Quit)

subMenu2 = Menu(menu,tearoff = 0)
menu.add_cascade(label = "Edit",menu = subMenu2)

subMenu2.add_cascade(label = "Change Font Size",menu = editMenu)
editMenu.add_command(label = "2",command = changeFontSize2)
editMenu.add_command(label = "6",command = changeFontSize6)
editMenu.add_command(label = "10(Default)",command = changeFontSize10)
editMenu.add_command(label = "14",command = changeFontSize14)
editMenu.add_command(label = "20",command = changeFontSize20)
editMenu.add_command(label = "24",command = changeFontSize24)
editMenu.add_command(label = "30",command = changeFontSize30)


subMenu2.add_command(label = "Title",command = Title)




root.geometry('800x800')

textPad.insert(END,"#")
textPad.insert(END,"\n")
textPad.insert(END,"Warning:The first line is the title of your file.If you dont want a title just remove this line and that one and if you want a title later just add '#' on the first line and select title or write after that")



root.mainloop()
