from urllib import urlopen
from Tkinter import *
from bs4 import BeautifulSoup as bs
import bleach

data = urlopen("http://www.laughfactory.com/jokes/latest-jokes")
soup = bs(data,"html.parser")

joke_of_the_day = soup.find_all("div",class_="joke-msg")[0]
filtered = bleach.clean(joke_of_the_day,tags = [],strip = True)
author_of_the_day = soup.find_all("span",class_="joke-publisher")[0]
filtered2 = bleach.clean(author_of_the_day,tags = [],strip = True)

root = Tk()

root.title("Joke of the day")
root.geometry("200x200+0+0")
root.resizable(width = False,height = False)

lab_joke = Label(root,text = filtered,wraplengt = 200)
lab_joke.pack(anchor = NW)
lab_author = Label(root,text = filtered2,font = ("Arial",20))
lab_author.place(y = 160,x = 0)

root.mainloop()
