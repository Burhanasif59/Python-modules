#Vowel counter(GUI)
#importing modules
from Tkinter import *

#The main window
root = Tk()

#Functions
def checker(event):
    check = ent_word.get()
    a = check.count("a")
    e = check.count("e")
    i = check.count("i")
    o = check.count("o")
    u = check.count("u")
    ans = a+e+i+o+u
    lab_vow_val.config(text = ans)
    lab_a_val.config(text = a)
    lab_e_val.config(text = e)
    lab_i_val.config(text = i)
    lab_o_val.config(text = o)
    lab_u_val.config(text = u )
    
#Title of the window
root.title("Vowel counter")
#Size of the window
root.geometry("280x250")
#Not making the window resize
root.resizable(width = False,height = False)
#Labels
lab_int = Label(root,text = "Please enter a word",font = ("Ariel"))
lab_vow = Label(root,text = "Total vowels:",font = ("Ariel",20))
lab_vow_val = Label(root,text = 0,font = ("Ariel",26))
lab_a = Label(root,text = "A:",font = ("Ariel",26),fg = "red")
lab_e = Label(root,text = "E:",font = ("Ariel",26),fg = "red")
lab_i = Label(root,text = "I:",font = ("Ariel",26),fg = "red")
lab_o = Label(root,text = "O:",font = ("Ariel",26),fg = "red")
lab_u = Label(root,text = "U:",font = ("Ariel",26),fg = "red")
lab_a_val = Label(root,text = 0,font = ("Ariel",16))
lab_e_val = Label(root,text = 0,font = ("Ariel",16))
lab_i_val = Label(root,text = 0,font = ("Ariel",16))
lab_o_val = Label(root,text = 0,font = ("Ariel",16))
lab_u_val = Label(root,text = 0,font = ("Ariel",16))
#Placing the labels
lab_int.place(x = 65,y = 15)
lab_vow.place(x = 0,y = 75)
lab_vow_val.place(x = 170,y = 72)
lab_a.place(x = 0,y = 122)
lab_e.place(x = 0,y = 192)
lab_i.place(x = 120,y = 122)
lab_o.place(x = 112,y = 192)
lab_u.place(x = 218, y = 122)
lab_a_val.place(x = 40,y = 132)
lab_e_val.place(x = 40,y = 202)
lab_u_val.place(x = 257,y = 132)
lab_i_val.place(x = 147,y = 132)
lab_o_val.place(x = 154,y = 202)

#Entries
ent_word = Entry(root)
#Placing the entries
ent_word.place(x = 73,y = 45)
#Binding the entries
ent_word.bind("<Return>",checker)

root.mainloop()
