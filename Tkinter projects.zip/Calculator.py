#Calculator
#Importing the modules
from Tkinter import *
import sys
import os

#----------------------------------------------------------------------
#variables
lst = []
lst2 = []
answer = []
#Functions


    
def restart_program():
    root = Tk()
    
    def getnum0(event):
        lst.append(0)
    def getnum1(event):
        lst.append(1)
    def getnum2(event):
        lst.append(2)
    def getnum3(event):
        lst.append(3)
    def getnum4(event):
        lst.append(4)
    def getnum5(event):
        lst.append(5)
    def getnum6(event):
        lst.append(6)
    def getnum7(event):
        lst.append(7)
    def getnum8(event):
        lst.append(8)
    def getnum9(event):
        lst.append(9)
    def getnum10(event):
        lst.append(10)
    #----------------------------------------------------------------------------------------
    def getnum0_2(event):
        lst2.append(0)
    def getnum1_2(event):
        lst2.append(1)
    def getnum2_2(event):
        lst2.append(2)
    def getnum3_2(event):
        lst2.append(3)
    def getnum4_2(event):
        lst2.append(4)
    def getnum5_2(event):
        lst2.append(5)
    def getnum6_2(event):
        lst2.append(6)
    def getnum7_2(event):
        lst2.append(7)
    def getnum8_2(event):
        lst2.append(8)
    def getnum9_2(event):
        lst2.append(9)
    def getnum10_2(event):
        lst2.append(10)


        
            
        
    def add(event):
        global answer
        global lst
        global lst2
        global b
        global z
        global t
        if lst2 == []:
            try:
                button_0.bind("<Button-1>",getnum0_2)
                button_1.bind("<Button-1>",getnum1_2)
                button_2.bind("<Button-1>",getnum2_2)
                button_3.bind("<Button-1>",getnum3_2)
                button_4.bind("<Button-1>",getnum4_2)
                button_5.bind("<Button-1>",getnum5_2)
                button_6.bind("<Button-1>",getnum6_2)
                button_7.bind("<Button-1>",getnum7_2)
                button_8.bind("<Button-1>",getnum8_2)
                button_9.bind("<Button-1>",getnum9_2)
                button_10.bind("<Button-1>",getnum10_2)
                b = int(''.join(map(str, lst)))
            except:
                pass
        else:
            try:
                z = int(''.join(map(str, lst2)))
                global b
                t = b + z 
                answer = []
                answer.append(t)
                lab_answer.config(text = answer[0])
                add_real()
            except:
                pass
            
    def add_real():
            global lst2
            lst2 = []
            try:
                button_0.bind("<Button-1>",getnum0_2)
                button_1.bind("<Button-1>",getnum1_2)
                button_2.bind("<Button-1>",getnum2_2)
                button_3.bind("<Button-1>",getnum3_2)
                button_4.bind("<Button-1>",getnum4_2)
                button_5.bind("<Button-1>",getnum5_2)
                button_6.bind("<Button-1>",getnum6_2)
                button_7.bind("<Button-1>",getnum7_2)
                button_8.bind("<Button-1>",getnum8_2)
                button_9.bind("<Button-1>",getnum9_2)
                button_10.bind("<Button-1>",getnum10_2)
                button_add.bind("<Button-1>",add_done)
                button_sub.bind("<Button-1>",sub_done)
                button_mul.bind("<Button-1>",mul_done)
                button_div.bind("<Button-1>",div_done)
            except:
                pass
    def add_done(event):
        global answer
        global lst2
        global z
        try:
            z = int(''.join(map(str, lst2)))
            answer.append(z)
            answer[0] = answer[0] + answer[1]
            answer.pop(1)
            lab_answer.config(text = answer[0])
            add_real()
        except:
            pass
        
    def sub(event):
        global answer
        global lst
        global lst2
        global b
        global z
        global t
        if lst2 == []:
            try:
                button_0.bind("<Button-1>",getnum0_2)
                button_1.bind("<Button-1>",getnum1_2)
                button_2.bind("<Button-1>",getnum2_2)
                button_3.bind("<Button-1>",getnum3_2)
                button_4.bind("<Button-1>",getnum4_2)
                button_5.bind("<Button-1>",getnum5_2)
                button_6.bind("<Button-1>",getnum6_2)
                button_7.bind("<Button-1>",getnum7_2)
                button_8.bind("<Button-1>",getnum8_2)
                button_9.bind("<Button-1>",getnum9_2)
                button_10.bind("<Button-1>",getnum10_2)
                b = int(''.join(map(str, lst)))
            except:
                pass
        else:
            try:
                z = int(''.join(map(str, lst2)))
                global b
                t = b - z 
                answer = []
                answer.append(t)
                lab_answer.config(text = answer[0])
                sub_real()
            except:
                pass
            
    def sub_real():
            global lst2
            lst2 = []
            button_0.bind("<Button-1>",getnum0_2)
            button_1.bind("<Button-1>",getnum1_2)
            button_2.bind("<Button-1>",getnum2_2)
            button_3.bind("<Button-1>",getnum3_2)
            button_4.bind("<Button-1>",getnum4_2)
            button_5.bind("<Button-1>",getnum5_2)
            button_6.bind("<Button-1>",getnum6_2)
            button_7.bind("<Button-1>",getnum7_2)
            button_8.bind("<Button-1>",getnum8_2)
            button_9.bind("<Button-1>",getnum9_2)
            button_10.bind("<Button-1>",getnum10_2)
            button_add.bind("<Button-1>",add_done)
            button_sub.bind("<Button-1>",sub_done)
            button_mul.bind("<Button-1>",mul_done)
            button_div.bind("<Button-1>",div_done)
    def sub_done(event):
        global answer
        global lst2
        global z
        try:
            z = int(''.join(map(str, lst2)))
            answer.append(z)
            answer[0] = answer[0] - answer[1]
            answer.pop(1)
            lab_answer.config(text = answer[0])
            sub_real()
        except:
            pass

    def mul(event):
        global answer
        global lst
        global lst2
        global b
        global z
        global t
        if lst2 == []:
            try:
                button_0.bind("<Button-1>",getnum0_2)
                button_1.bind("<Button-1>",getnum1_2)
                button_2.bind("<Button-1>",getnum2_2)
                button_3.bind("<Button-1>",getnum3_2)
                button_4.bind("<Button-1>",getnum4_2)
                button_5.bind("<Button-1>",getnum5_2)
                button_6.bind("<Button-1>",getnum6_2)
                button_7.bind("<Button-1>",getnum7_2)
                button_8.bind("<Button-1>",getnum8_2)
                button_9.bind("<Button-1>",getnum9_2)
                button_10.bind("<Button-1>",getnum10_2)
                b = int(''.join(map(str, lst)))
            except:
                pass
        else:
            try:
                z = int(''.join(map(str, lst2)))
                global b
                t = b * z 
                answer = []
                answer.append(t)
                lab_answer.config(text = answer[0])
                mul_real()
            except:
                pass
            
    def mul_real():
            global lst2
            lst2 = []
            button_0.bind("<Button-1>",getnum0_2)
            button_1.bind("<Button-1>",getnum1_2)
            button_2.bind("<Button-1>",getnum2_2)
            button_3.bind("<Button-1>",getnum3_2)
            button_4.bind("<Button-1>",getnum4_2)
            button_5.bind("<Button-1>",getnum5_2)
            button_6.bind("<Button-1>",getnum6_2)
            button_7.bind("<Button-1>",getnum7_2)
            button_8.bind("<Button-1>",getnum8_2)
            button_9.bind("<Button-1>",getnum9_2)
            button_10.bind("<Button-1>",getnum10_2)
            button_add.bind("<Button-1>",add_done)
            button_sub.bind("<Button-1>",sub_done)
            button_mul.bind("<Button-1>",mul_done)
            button_div.bind("<Button-1>",div_done)
    def mul_done(event):
        global answer
        global lst2
        global z
        try:
            z = int(''.join(map(str, lst2)))
            answer.append(z)
            answer[0] = answer[0] * answer[1]
            answer.pop(1)
            lab_answer.config(text = answer[0])
            mul_real()
        except:
            pass

    def div(event):
        global answer
        global lst
        global lst2
        global b
        global z
        global t
        if lst2 == []:
            try:
                button_0.bind("<Button-1>",getnum0_2)
                button_1.bind("<Button-1>",getnum1_2)
                button_2.bind("<Button-1>",getnum2_2)
                button_3.bind("<Button-1>",getnum3_2)
                button_4.bind("<Button-1>",getnum4_2)
                button_5.bind("<Button-1>",getnum5_2)
                button_6.bind("<Button-1>",getnum6_2)
                button_7.bind("<Button-1>",getnum7_2)
                button_8.bind("<Button-1>",getnum8_2)
                button_9.bind("<Button-1>",getnum9_2)
                button_10.bind("<Button-1>",getnum10_2)
                b = int(''.join(map(str, lst)))
            except:
                pass
        else:
            try:
                z = int(''.join(map(str, lst2)))
                global b
                t = b / z 
                answer = []
                answer.append(t)
                lab_answer.config(text = answer[0])
                div_real()
            except:
                pass
            
    def div_real():
            global lst2
            lst2 = []
            button_0.bind("<Button-1>",getnum0_2)
            button_1.bind("<Button-1>",getnum1_2)
            button_2.bind("<Button-1>",getnum2_2)
            button_3.bind("<Button-1>",getnum3_2)
            button_4.bind("<Button-1>",getnum4_2)
            button_5.bind("<Button-1>",getnum5_2)
            button_6.bind("<Button-1>",getnum6_2)
            button_7.bind("<Button-1>",getnum7_2)
            button_8.bind("<Button-1>",getnum8_2)
            button_9.bind("<Button-1>",getnum9_2)
            button_10.bind("<Button-1>",getnum10_2)
            button_add.bind("<Button-1>",add_done)
            button_sub.bind("<Button-1>",sub_done)
            button_mul.bind("<Button-1>",mul_done)
            button_div.bind("<Button-1>",div_done)
    def div_done(event):
        global answer
        global lst2
        global z
        try:
            z = int(''.join(map(str, lst2)))
            answer.append(z)
            answer[0] = answer[0] / answer[1]
            answer.pop(1)
            lab_answer.config(text = answer[0])
            div_real()
        except:
            pass

    def destroy():
        global lst
        global lst2
        global answer
        answer = []
        lst = []
        lst2 = []
        root.destroy()
        restart_program()

        
        
    #Title,size and not making the window resizable
    root.title("Calculator")
    root.geometry("250x300")
    root.resizable(width = False,height = False)
    #-----------------------------------------------------------------------------
    #labels
    lab_diff = Label(text = "________________________________________________")
    lab_answer = Label(text = 0,font = ("Arial",20))
    #-----------------------------------------------------------------------------
    #placing the labels
    lab_diff.place(x = 2,y = 30)
    lab_answer.place(x = 0,y = 0)
    #-----------------------------------------------------------------------------
    #The Buttons
    button_0 = Button(root,text = "0",width = 5,height = 2,font = ("Arial",10))
    button_1 = Button(root,text = "1",width = 5,height = 2,font = ("Arial",10))
    button_2 = Button(text = "2",width = 5,height = 2,font = ("Arial",10))
    button_3 = Button(text = "3",width = 5,height = 2,font = ("Arial",10))
    button_4 = Button(text = "4",width = 5,height = 2,font = ("Arial",10))
    button_5 = Button(text = "5",width = 5,height = 2,font = ("Arial",10))
    button_6 = Button(root,text = "6",width = 5,height = 2,font = ("Arial",10))
    button_7 = Button(root,text = "7",width = 5,height = 2,font = ("Arial",10))
    button_8 = Button(text = "8",width = 5,height = 2,font = ("Arial",10))
    button_9 = Button(text = "9",width = 5,height = 2,font = ("Arial",10))
    button_10 = Button(text = "10",width = 5,height = 2,font = ("Arial",10))
    button_add =  Button(text = "+",width = 5,height = 2,font = ("Arial",10))
    button_sub =  Button(text = "-",width = 5,height = 2,font = ("Arial",10))
    button_mul =  Button(text = "*",width = 5,height = 2,font = ("Arial",10))
    button_div =  Button(text = "/",width = 5,height = 2,font = ("Arial",10))
    button_clear =  Button(text = "C",width = 5,height = 2,font = ("Arial",10),command = destroy)
    #-----------------------------------------------------------------------------
    #Placing the buttons
    button_0.place(x = 10,y = 240)
    button_1.place(x = 70,y = 240)
    button_2.place(x = 130,y = 240)
    button_3.place(x = 10,y = 180)
    button_4.place(x = 70,y = 180)
    button_5.place(x = 130,y = 180)
    button_6.place(x = 10,y = 120)
    button_7.place(x = 70,y = 120)
    button_8.place(x = 130,y = 120)
    button_9.place(x = 10,y = 60)
    button_10.place(x = 70,y = 60)
    button_add.place(x = 190,y = 240)
    button_sub.place(x = 190,y = 180)
    button_mul.place(x = 190,y = 120)
    button_div.place(x = 130, y = 60)
    button_clear.place(x = 190,y = 60)
    #-------------------------------------------------------------------------------
    #Variables
    
    #Bimding the buttons
    button_0.bind("<Button-1>",getnum0)
    button_1.bind("<Button-1>",getnum1)
    button_2.bind("<Button-1>",getnum2)
    button_3.bind("<Button-1>",getnum3)
    button_4.bind("<Button-1>",getnum4)
    button_5.bind("<Button-1>",getnum5)
    button_6.bind("<Button-1>",getnum6)
    button_7.bind("<Button-1>",getnum7)
    button_8.bind("<Button-1>",getnum8)
    button_9.bind("<Button-1>",getnum9)
    button_10.bind("<Button-1>",getnum10)
    button_add.bind("<Button-1>",add)
    button_sub.bind("<Button-1>",sub)
    button_mul.bind("<Button-1>",mul)
    button_div.bind("<Button-1>",div)
    root.mainloop()
    

restart_program()
