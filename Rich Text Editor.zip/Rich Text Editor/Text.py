#!/usr/bin/python
# -*- coding: utf-8 -*-
import sys
from PyQt4 import QtGui, QtCore
from PyQt4.QtGui import *
from PyQt4.QtCore import *
import os
import pyautogui
import time
import re

sizeX = 1000
sizeY = 800
x = 2
saveCheck = False
zoomCheck = 0
zoomFile = open('prints.txt', 'r')
zoomFile.close()
windowTitle = 'Rich Text Editor'

with open('prints.txt', 'r') as f:
    pOrientation = f.readlines()[0]
    f.seek(0)
    pSizeY = int(f.readlines()[1])
    f.seek(0)
    pSizeX = int(f.readlines()[2])
    f.seek(0)
    pUnit = f.readlines()[3]
    f.seek(0)
    pCount = int(f.readlines()[4])
    f.seek(0)
    pFullpage = bool(f.readlines()[5])
    f.seek(0)


class Window(QtGui.QMainWindow):

    def __init__(self):
        super(Window, self).__init__()
        self.setGeometry(50, 50, sizeX, sizeY)
        self.setWindowTitle('Rich Text Editor')
        self.setWindowIcon(QtGui.QIcon('black.png'))
        self.undoStack = QtGui.QUndoStack()
        self.printer = QtGui.QPrinter(mode=72)
        self.printer.setPaperSize(QtCore.QSizeF(pSizeY, pSizeY),
                                  self.printer.Millimeter * 10)
        self.printer.setCopyCount(pCount)
        self.printer.setFullPage(pFullpage)
        self.statusBar = QStatusBar()
        self.textEdit = QtGui.QTextEdit()
        self.setCentralWidget(self.textEdit)
        self.setStatusBar(self.statusBar)

        openAction = QtGui.QAction('Open', self)
        openAction.setShortcut('Ctrl+O')
        openAction.setStatusTip('Open File')
        openAction.triggered.connect(self.openApp)

        closeAction = QtGui.QAction('Exit', self)
        closeAction.setShortcut('Ctrl+Q')
        closeAction.setStatusTip('Close File')
        closeAction.triggered.connect(self.closeApp)

        saveAction = QtGui.QAction('Save', self)
        saveAction.setShortcut('Ctrl+S')
        saveAction.setStatusTip('Save File')
        saveAction.triggered.connect(self.saveApp)

        fontAction = QtGui.QAction('Change Font', self)
        fontAction.setShortcut('Ctrl+F')
        fontAction.setStatusTip('Change the font')
        fontAction.triggered.connect(self.changeFont)

        capitalAction = QtGui.QAction('Make Uppercase', self)
        capitalAction.setShortcut('Ctrl+N')
        capitalAction.setStatusTip('Make the text Uppercase')
        capitalAction.triggered.connect(self.changeCapital)

        smallAction = QtGui.QAction('Make Lowercase', self)
        smallAction.setShortcut('Ctrl+M')
        smallAction.setStatusTip('Make the text Lowercase')
        smallAction.triggered.connect(self.changeSmall)

        colorAction = QtGui.QAction('Change Foreground Color', self)
        colorAction.setShortcut('Ctrl+L')
        colorAction.setStatusTip('Change the Foreground color of the text'
                                 )
        colorAction.triggered.connect(self.changeColor)

        colorBGAction = QtGui.QAction('Change Background Color', self)
        colorBGAction.setShortcut('Ctrl+K')
        colorBGAction.setStatusTip('Change the Background color of the text'
                                   )
        colorBGAction.triggered.connect(self.changeColorBG)

        copyrightAction = QtGui.QAction('Copyrights', self)
        copyrightAction.setShortcut('Ctrl+G')
        copyrightAction.setStatusTip("View 'Text editor' copyrights")
        copyrightAction.triggered.connect(self.copyRights)

        zoomInAction = QtGui.QAction('Increase window size', self)
        zoomInAction.setShortcut('Ctrl+I')
        zoomInAction.setStatusTip('Increase the window size')
        zoomInAction.triggered.connect(self.zoomIn)

        zoomOutAction = QtGui.QAction('Decrease window size', self)
        zoomOutAction.setShortcut('Ctrl+U')
        zoomOutAction.setStatusTip('Decrease the window size')
        zoomOutAction.triggered.connect(self.zoomOut)

        changeBoldAction = QtGui.QAction('Make Bold', self)
        changeBoldAction.setShortcut('Ctrl+B')
        changeBoldAction.setStatusTip('Make the text bold')
        changeBoldAction.triggered.connect(self.changeBold)

        changeItalicAction = QtGui.QAction('Make Italic', self)
        changeItalicAction.setShortcut('Ctrl+H')
        changeItalicAction.setStatusTip('Make the text italic')
        changeItalicAction.triggered.connect(self.changeItalic)

        changeFontUnderlineAction = QtGui.QAction('Underline', self)
        changeFontUnderlineAction.setShortcut('Ctrl+J')
        changeFontUnderlineAction.setStatusTip('Make the text underlined'
                )
        changeFontUnderlineAction.triggered.connect(self.changeUnderline)

        redoAction = QtGui.QAction('Redo', self)
        redoAction.setShortcut('Ctrl+Shift+Z')
        redoAction.setStatusTip('Redo your previous action')
        redoAction.triggered.connect(self.makeRedo)

        undoAction = QtGui.QAction('Undo', self)
        undoAction.setShortcut('Ctrl+X')
        undoAction.setStatusTip('Undo your last action')
        undoAction.triggered.connect(self.makeUndo)

        printAction = QtGui.QAction('Print', self)
        printAction.setShortcut('Ctrl+P')
        printAction.setStatusTip('Print your document')
        printAction.triggered.connect(self.prints)

        findAction = QtGui.QAction('Find', self)
        findAction.setShortcut('Ctrl+D')
        findAction.setStatusTip('Find the given text in your docuemnt')
        findAction.triggered.connect(self.finds)

        clearAction = QtGui.QAction('Clear', self)
        clearAction.setShortcut('Ctrl+R')
        clearAction.setStatusTip('Clear all the text on the screen(undo and redo history is deleted)'
                                 )
        clearAction.triggered.connect(self.clear)

        zoomInMAction = QtGui.QAction('Zoom-in', self)
        zoomInMAction.setShortcut('Ctrl++')
        zoomInMAction.setStatusTip('Magnify the view')
        zoomInMAction.triggered.connect(self.magnify)

        zoomOutMAction = QtGui.QAction('Zoom-out', self)
        zoomOutMAction.setShortcut('Ctrl+-')
        zoomOutMAction.setStatusTip('Demagnify the view')
        zoomOutMAction.triggered.connect(self.demagnify)

        alRightAction = QtGui.QAction('Alignment-right', self)
        alRightAction.setShortcut('Ctrl+Shift+R')
        alRightAction.setStatusTip('Make the text alignment to the right'
                                   )
        alRightAction.triggered.connect(self.alRight)

        alLeftAction = QtGui.QAction('Alignment-left', self)
        alLeftAction.setShortcut('Ctrl+Shift+L')
        alLeftAction.setStatusTip('Make the text alignment to the left')
        alLeftAction.triggered.connect(self.alLeft)

        alCenterAction = QtGui.QAction('Alignment-center', self)
        alCenterAction.setShortcut('Ctrl+Shift+C')
        alCenterAction.setStatusTip('Make the text alignment to the center'
                                    )
        alCenterAction.triggered.connect(self.alCenter)

        alJustifyAction = QtGui.QAction('Alignment-justify', self)
        alJustifyAction.setShortcut('Ctrl+Shift+J')
        alJustifyAction.setStatusTip('Make the text alignment to justify'
                )
        alJustifyAction.triggered.connect(self.alJustify)

        saveAsAction = QtGui.QAction('Save As', self)
        saveAsAction.setShortcut('Ctrl+Shift+S')
        saveAsAction.setStatusTip('Save a separate copy of your document'
                                  )
        saveAsAction.triggered.connect(self.saveAsApp)

        indentAction = QtGui.QAction('Increase Indent', self)
        indentAction.setShortcut('Ctrl+[')
        indentAction.setStatusTip('Indent the selected text')
        indentAction.triggered.connect(self.indent)

        deindentAction = QtGui.QAction('Decrease indent', self)
        deindentAction.setShortcut('Ctrl+]')
        deindentAction.setStatusTip('Deindent the selected text')
        deindentAction.triggered.connect(self.deindent)

        bulletListAction = QtGui.QAction('Create bullet list', self)
        bulletListAction.setShortcut('Ctrl+Shift+1')
        bulletListAction.setStatusTip('Insert a bullet list in your docuemnt'
                )
        bulletListAction.triggered.connect(self.bulletList)

        numberListAction = QtGui.QAction('Create numbered list', self)
        numberListAction.setShortcut('Ctrl+Shift+2')
        numberListAction.setStatusTip('Insert a numbered list in your docuemnt'
                )
        numberListAction.triggered.connect(self.numberList)

        resetAction = QtGui.QAction('Reset view', self)
        resetAction.setShortcut('Ctrl+Shift+V')
        resetAction.setStatusTip('Reset the Original view')
        resetAction.triggered.connect(self.resetView)

        mainMenu = self.menuBar()
        fileMenu = mainMenu.addMenu('&File')
        fileMenu.addAction(openAction)
        fileMenu.addAction(closeAction)
        fileMenu.addAction(saveAction)
        fileMenu.addAction(saveAsAction)

        editMenu = mainMenu.addMenu('&Edit')
        editMenu.addAction(colorAction)
        editMenu.addAction(colorBGAction)
        editMenu.addAction(capitalAction)
        editMenu.addAction(smallAction)
        editMenu.addAction(changeBoldAction)
        editMenu.addAction(changeItalicAction)
        editMenu.addAction(changeFontUnderlineAction)
        editMenu.addAction(undoAction)
        editMenu.addAction(redoAction)
        editMenu.addAction(alLeftAction)
        editMenu.addAction(alRightAction)
        editMenu.addAction(alCenterAction)
        editMenu.addAction(alJustifyAction)
        editMenu.addAction(indentAction)
        editMenu.addAction(deindentAction)
        editMenu.addAction(bulletListAction)
        editMenu.addAction(numberListAction)
        editMenu.addAction(clearAction)

        helpMenu = mainMenu.addMenu('&Help')
        helpMenu.addAction(copyrightAction)

        viewMenu = mainMenu.addMenu('&View')
        viewMenu.addAction(findAction)
        viewMenu.addAction(zoomInAction)
        viewMenu.addAction(zoomOutAction)
        viewMenu.addAction(zoomInMAction)
        viewMenu.addAction(zoomOutMAction)
        viewMenu.addAction(resetAction)

        printMenu = mainMenu.addMenu('&Print')
        printMenu.addAction(printAction)

        self.home()

    def home(self):

        self.fontComboBox = QFontComboBox()
        self.fontComboBox.setEditable(False)
        self.fontComboBox.activated[str].connect(self.changeFontTB)

        self.fontSizeComboBox = QComboBox()
        self.fontSizeComboBox.addItem('2 px')
        self.fontSizeComboBox.addItem('4 px')
        self.fontSizeComboBox.addItem('8 px')
        self.fontSizeComboBox.addItem('12 px')
        self.fontSizeComboBox.addItem('14 px')
        self.fontSizeComboBox.addItem('16 px')
        self.fontSizeComboBox.addItem('18 px')
        self.fontSizeComboBox.addItem('20 px')
        self.fontSizeComboBox.addItem('24 px')
        self.fontSizeComboBox.addItem('35 px')
        self.fontSizeComboBox.addItem('40 px')
        self.fontSizeComboBox.addItem('50 px')
        self.fontSizeComboBox.addItem('60 px')
        self.fontSizeComboBox.addItem('65 px')
        self.fontSizeComboBox.addItem('72 px')
        self.fontSizeComboBox.activated[str].connect(self.changeSizeTB)

        self.textEdit.setFontPointSize(20)
        self.textEdit.setFontFamily('Tahoma')

        closeActionTB = \
            QtGui.QAction(QtGui.QIcon('cross-circular-button.png'),
                          'Close the app', self)
        closeActionTB.triggered.connect(self.closeApp)

        openActionTB = \
            QtGui.QAction(QtGui.QIcon('open-folder-outline.png'),
                          'Open a file', self)
        openActionTB.triggered.connect(self.openApp)

        saveActionTB = \
            QtGui.QAction(QtGui.QIcon('save-icon-silhouette.png'),
                          'Save a file', self)
        saveActionTB.triggered.connect(self.saveApp)

##        changeFontActionTB = QtGui.QAction(self.fontComboBox,"Change the font",self)
##        changeFontActionTB.triggered.connect(self.changeFont)

        copyRightsTB = QtGui.QAction(QtGui.QIcon('copyright.png'),
                "View 'Text editor' copyrights", self)
        copyRightsTB.triggered.connect(self.copyRights)

        capitalActionTB = QtGui.QAction(QtGui.QIcon('alpha.png'),
                'Make the text Uppercase', self)
        capitalActionTB.triggered.connect(self.changeCapital)

        smallActionTB = QtGui.QAction(QtGui.QIcon('delta.png'),
                'Make the text Lowercasel', self)
        smallActionTB.triggered.connect(self.changeSmall)

        colorActionTB = QtGui.QAction(QtGui.QIcon('painter-palette.png'
                ), 'Change the foreground color of the text', self)
        colorActionTB.triggered.connect(self.changeColor)

        colorActionBGTB = QtGui.QAction(QtGui.QIcon('highlighter.png'),
                'Change the background color of the text', self)
        colorActionBGTB.triggered.connect(self.changeColorBG)

        zoomInActionTB = \
            QtGui.QAction(QtGui.QIcon('plus-circular-button.png'),
                          'Increase the window size', self)
        zoomInActionTB.triggered.connect(self.zoomIn)

        zoomOutActionTB = \
            QtGui.QAction(QtGui.QIcon('minus-sign-inside-a-black-circle.png'
                          ), 'Decrease the window size', self)
        zoomOutActionTB.triggered.connect(self.zoomOut)

        changeBoldActionTB = \
            QtGui.QAction(QtGui.QIcon('bold-text-option.png'),
                          'Make the text bold', self)
        changeBoldActionTB.triggered.connect(self.changeBold)

        changeItalicActionTB = \
            QtGui.QAction(QtGui.QIcon('italic-text.png'),
                          'Make the text italic', self)
        changeItalicActionTB.triggered.connect(self.changeItalic)

        changeFontUnderlineActionTB = \
            QtGui.QAction(QtGui.QIcon('underline-text-button.png'),
                          'Make the text underlined', self)
        changeFontUnderlineActionTB.triggered.connect(self.changeUnderline)

        redoActionTB = QtGui.QAction(QtGui.QIcon('redo-arrow.png'),
                'Redo your previous action', self)
        redoActionTB.triggered.connect(self.makeRedo)

        undoActionTB = QtGui.QAction(QtGui.QIcon('undo-arrow.png'),
                'Undo your last action', self)
        undoActionTB.triggered.connect(self.makeUndo)

        printActionTB = QtGui.QAction(QtGui.QIcon('printer-.png'),
                'Print your document', self)
        printActionTB.triggered.connect(self.prints)

        findActionTB = QtGui.QAction(QtGui.QIcon('magnifying-glass.png'
                ), 'Find the given text in your document', self)
        findActionTB.triggered.connect(self.finds)

        clearTB = QtGui.QAction(QtGui.QIcon('delete.png'),
                                'Clear all the text on the screen(undo and redo history is deleted)'
                                , self)
        clearTB.triggered.connect(self.clear)

        magnifyTB = QtGui.QAction(QtGui.QIcon('zoom-in.png'),
                                  'Magnify the view', self)
        magnifyTB.triggered.connect(self.magnify)

        demagnifyTB = QtGui.QAction(QtGui.QIcon('zoom-out.png'),
                                    'Demagnify the view', self)
        demagnifyTB.triggered.connect(self.demagnify)

        alRightTB = QtGui.QAction(QtGui.QIcon('align-to-right.png'),
                                  'Make the text alignment to the right'
                                  , self)
        alRightTB.triggered.connect(self.alRight)

        alLeftTB = QtGui.QAction(QtGui.QIcon('align-to-left.png'),
                                 'Make the text alignment to the left',
                                 self)
        alLeftTB.triggered.connect(self.alLeft)

        alCenterTB = \
            QtGui.QAction(QtGui.QIcon('center-text-alignment.png'),
                          'Make the text alignment to the center', self)
        alCenterTB.triggered.connect(self.alCenter)

        alJustifyTB = QtGui.QAction(QtGui.QIcon('align-justify.png'),
                                    'Make the text alignment to justify'
                                    , self)
        alJustifyTB.triggered.connect(self.alJustify)

        indentTB = QtGui.QAction(QtGui.QIcon('right-arrow.png'),
                                 'Indent the selected text', self)
        indentTB.triggered.connect(self.indent)

        deindentTB = QtGui.QAction(QtGui.QIcon('left-arrow.png'),
                                   'Deindent the selected text', self)
        deindentTB.triggered.connect(self.deindent)

        bulletListActionTB = QtGui.QAction(QtGui.QIcon('bullet.png'),
                'Insert a bullet list in your document', self)
        bulletListActionTB.triggered.connect(self.bulletList)

        numberListActionTB = QtGui.QAction(QtGui.QIcon('number.png'),
                'Insert a numbered list in your document', self)
        numberListActionTB.triggered.connect(self.numberList)

        resetViewTB = QtGui.QAction(QtGui.QIcon('original-size.png'),
                                    'Reset the original view', self)
        resetViewTB.triggered.connect(self.resetView)

        self.formatbar = QToolBar()
        self.addToolBar(Qt.TopToolBarArea, self.formatbar)
        self.formatbar.addSeparator()
        self.formatbar.addWidget(self.fontComboBox)
        self.formatbar.addWidget(self.fontSizeComboBox)
        self.formatbar.addAction(closeActionTB)
        self.formatbar.addAction(openActionTB)
        self.formatbar.addAction(saveActionTB)
        self.formatbar.addAction(capitalActionTB)
        self.formatbar.addAction(smallActionTB)
        self.formatbar.addAction(colorActionTB)
        self.formatbar.addAction(colorActionBGTB)
        self.formatbar.addAction(zoomInActionTB)
        self.formatbar.addAction(zoomOutActionTB)
        self.formatbar.addAction(changeBoldActionTB)
        self.formatbar.addAction(changeItalicActionTB)
        self.formatbar.addAction(changeFontUnderlineActionTB)
        self.formatbar.addAction(undoActionTB)
        self.formatbar.addAction(redoActionTB)
        self.formatbar.addAction(magnifyTB)
        self.formatbar.addAction(demagnifyTB)
        self.formatbar.addAction(resetViewTB)
        self.formatbar.addAction(findActionTB)
        self.formatbar.addAction(printActionTB)
        self.formatbar.addAction(alLeftTB)
        self.formatbar.addAction(alRightTB)
        self.formatbar.addAction(alCenterTB)
        self.formatbar.addAction(alJustifyTB)
        self.formatbar.addAction(bulletListActionTB)
        self.addToolBarBreak(Qt.TopToolBarArea)
        self.formatbar2 = QToolBar()
        self.addToolBar(Qt.TopToolBarArea, self.formatbar2)
        self.formatbar2.addAction(numberListActionTB)
        self.formatbar2.addAction(indentTB)
        self.formatbar2.addAction(deindentTB)
        self.formatbar2.addAction(clearTB)
        self.formatbar2.addAction(copyRightsTB)

        self.show()

    def closeEvent(self, event):
        quit_msg = 'Do you want to exit rich text editor?'
        reply = QtGui.QMessageBox.question(
            self,
            'Exit',
            quit_msg,
            QtGui.QMessageBox.Save,
            QtGui.QMessageBox.No,
            QtGui.QMessageBox.Cancel,
            )

        if reply == QtGui.QMessageBox.No:
            event.accept()
        elif reply == QtGui.QMessageBox.Save:

            self.saveApp()
        else:
            event.ignore()

    def closeApp(self):
        quit_msg = 'Do you want to exit rich text editor?'
        reply = QtGui.QMessageBox.question(
            self,
            'Exit',
            quit_msg,
            QtGui.QMessageBox.Save,
            QtGui.QMessageBox.No,
            QtGui.QMessageBox.Cancel,
            )

        if reply == QtGui.QMessageBox.Save:
            self.saveApp()
        elif reply == QtGui.QMessageBox.No:
            sys.exit()
        else:
            pass

    def openApp(self):
        global zoomCheck
        global saveCheck
        global windowTitle
        global zoomFile
        global name
        try:
            name = QtGui.QFileDialog.getOpenFileName(self, 'Open File')
            windowTitle = name.split('/')[-1]
            self.setWindowTitle(windowTitle)
            files = open(name, 'r')
            with files:
                text = files.read()
                self.textEdit.setText(text)
                saveCheck = True
        except:

##            zoomFile = open("C:\Users\Burhan\AppData\Roaming\RTE\%s.txt" % name.split("/")[-1],"w")
##            zoomFile.close()
##            zoomFile = open("C:\Users\Burhan\AppData\Roaming\RTE\%s.txt" %name.split("/")[-1],"r+")
##            x = zoomFile.read()
##            if len(x) == 0:
##                zoomFile.close()
##                zoomFile = open("C:\Users\Burhan\AppData\Roaming\RTE\%s.txt" % name.split("/")[-1],"w")
##                zoomFile.close()

            pass

    def saveApp(self):
        global zoomFile
        global colors
        global font
        global saveCheck
        global windowTitle
        global name
        global zoomCheck
        cursor = self.textEdit.textCursor()
        cursorPos = cursor.position()
        try:
            if not saveCheck:
                name = QtGui.QFileDialog.getSaveFileName(self,
                        'save File')
                files = open(name, 'w')
                text = self.textEdit.toHtml()
                files.write(text)
                files.close()
                saveCheck = True
                windowTitle = name.split('/')[-1]
                self.setWindowTitle(windowTitle)
                zoomFile = \
                    open("C:\Users\Burhan\AppData\Roaming\RTE\%s.txt"
                         % name.split('/')[-1], 'w')
                zoomFile.close()
                zoomFile = \
                    open("C:\Users\Burhan\AppData\Roaming\RTE\%s.txt"
                         % name.split('/')[-1], 'w')
                zoomFile.write(str(zoomCheck))
                zoomFile.close()
            elif windowTitle != 'Rich Text Editor':
                files = open(name, 'w')
                text = self.textEdit.toHtml()
                files.write(text)
                files.close()
        except:
            pass
        try:
            cursor.setPosition(cursorPos)
            self.textEdit.setTextCursor(cursor)
        except:
            pass

    def changeFont(self):
        global font
        textSelected = ''
        try:

                # The Cursor

            cursor = self.textEdit.textCursor()

                # Getting the cursor format

            formats = cursor.charFormat()

                # Asking for font

            (font, valid) = QtGui.QFontDialog.getFont()
            if valid:
                formats.setFont(font)

                    # setting the font

                cursor.setCharFormat(formats)

                    # appliying it

                textSelected = cursor.selectedText()
                if len(textSelected) == 0:
                    self.textEdit.setCurrentFont(font)
        except:

            pass

    def undo(self):
        self.undoStack.undo(self.textEdit)

    def copyRights(self):
        msg = QtGui.QMessageBox(self)
        msg.setIcon(QtGui.QMessageBox.Information)
        msg.setWindowIcon(QtGui.QIcon('icon.png'))
        msg.setWindowTitle('Copyrights')
        msg.setDetailedText("""All programming and coding done by Burhan Asif

All icons by 'FLATICONS'(http://www.flaticon.com)

Python language used for coding and PyQt use for GUI

Text Editor and It's copyrights belong to Burhan Asif

""")
        msg.resize(800, 800)
        msg.setText('Click "Show Details" to view the copyright details'
                    )
        msg.exec_()

    def changeCapital(self):
        try:
            cursor = self.textEdit.textCursor()
            formats = cursor.charFormat()
            cursor.setCharFormat(formats)
            textSelected = str(cursor.selectedText()).upper()
            cursor.insertText(textSelected)
        except:
            pass

    def changeSmall(self):
        try:
            cursor = self.textEdit.textCursor()
            formats = cursor.charFormat()
            cursor.setCharFormat(formats)
            textSelected = str(cursor.selectedText()).lower()
            cursor.insertText(textSelected)
        except:
            pass

    def changeColor(self):
        global colors
        try:
            cursor = self.textEdit.textCursor()
            formats = cursor.charFormat()
            colors = QtGui.QColorDialog.getColor()
            textSelected = cursor.selectedText()
            if len(textSelected) == 0:
                    self.textEdit.setTextColor(colors)
            elif len(textSelected) > 0:
                    restore = cursor.position()
                    cursorEnd = cursor.selectionEnd()
                    cursor.setPosition(cursor.selectionStart())
                    self.textEdit.setTextCursor(cursor)
                    while cursorEnd > cursor.position():
                        cursor.movePosition(17, 1)
                        self.textEdit.setTextCursor(cursor)
                        formats = cursor.charFormat()
                        formats.setForeground(colors)
                        cursor.setCharFormat(formats)
                        cursor.setPosition(cursor.position(), 0)
                    cursor.setPosition(restore)
        except:
            pass

    def changeColorBG(self):
        global colors
        try:
            cursor = self.textEdit.textCursor()
            formats = cursor.charFormat()
            colors = QtGui.QColorDialog.getColor()
            textSelected = cursor.selectedText()
            if len(textSelected) == 0:
                    self.textEdit.setTextBackgroundColor(colors)
            elif len(textSelected) > 0:
                    restore = cursor.position()
                    cursorEnd = cursor.selectionEnd()
                    cursor.setPosition(cursor.selectionStart())
                    self.textEdit.setTextCursor(cursor)
                    while cursorEnd > cursor.position():
                        cursor.movePosition(17, 1)
                        self.textEdit.setTextCursor(cursor)
                        formats = cursor.charFormat()
                        formats.setBackground(colors)
                        cursor.setCharFormat(formats)
                        cursor.setPosition(cursor.position(), 0)
                    cursor.setPosition(restore)
        except:
            pass

    def zoomIn(self):
        global sizeX
        global sizeY
        sizeX += 100
        sizeY += 100
        self.resize(sizeX, sizeY)

    def zoomOut(self):
        global sizeX
        global sizeY
        sizeX -= 100
        sizeY -= 100
        self.resize(sizeX, sizeY)

    def changeBold(self):
        try:
            cursor = self.textEdit.textCursor()
            formats = cursor.charFormat()
            if formats.fontWeight() == 50:
                formats.setFontFamily(formats.fontFamily())
                formats.setFontWeight(500)
                cursor.setCharFormat(formats)
                textSelected = cursor.selectedText()
                if len(textSelected) == 0:
                    formats.setFontFamily(formats.fontFamily())
                    self.textEdit.setFontWeight(500)
            elif formats.fontWeight() == 500:
                formats.setFontWeight(50)
                cursor.setCharFormat(formats)
                textSelected = cursor.selectedText()
                if len(textSelected) == 0:
                    self.textEdit.setFontWeight(50)
        except:
            pass

    def changeItalic(self):
        try:
            cursor = self.textEdit.textCursor()
            formats = cursor.charFormat()
            if not formats.fontItalic():
                formats.setFontItalic(True)
                cursor.setCharFormat(formats)
                textSelected = cursor.selectedText()
                if len(textSelected) == 0:
                    self.textEdit.setFontItalic(True)
            elif formats.fontItalic():
                formats.setFontItalic(False)
                cursor.setCharFormat(formats)
                textSelected = cursor.selectedText()
                if len(textSelected == 0):
                    self.textEdit.setFontItalic(False)
        except:
            pass

    def changeUnderline(self):
        try:
            cursor = self.textEdit.textCursor()
            formats = cursor.charFormat()
            if not formats.fontUnderline():
                formats.setFontUnderline(True)
                cursor.setCharFormat(formats)
                textSelected = cursor.selectedText()
                if len(textSelected) == 0:
                    self.textEdit.setFontUnderline(True)
            elif formats.fontUnderline():
                formats.setFontUnderline(False)
                cursor.setCharFormat(formats)
                textSelected = cursor.selectedText()
                if len(textSelected) == 0:
                    self.textEdit.setFontUnderline(False)
        except:
            pass

    def makeRedo(self):
        self.textEdit.redo()

    def makeUndo(self):
        self.textEdit.undo()

    def prints(self):
        dialog = QtGui.QPrintDialog()
        if dialog.exec_() == QtGui.QDialog.Accepted:
            self.textEdit.document().print_(dialog.printer())

    def finds(self):
        cursor = self.textEdit.textCursor()
        cursor.setPosition(0)
        self.textEdit.setTextCursor(cursor)
        (find, ok) = QtGui.QInputDialog.getText(self, 'Find',
                'Please enter the text you want to find')
        self.textEdit.find(find)

    def clear(self):
        msg = QtGui.QMessageBox(self)
        msg.setIcon(QtGui.QMessageBox.Warning)
        msg.setWindowTitle('Clear')
        msg.setWindowIcon(QtGui.QIcon('delete.png'))
        msg.setText("""Are you sure you want to clear all the text in the document

Note:Undo and redo histories are also deleted""")

        choice = msg.setStandardButtons(QtGui.QMessageBox.Ok
                | QtGui.QMessageBox.Cancel)
        msg.setDefaultButton(QtGui.QMessageBox.Cancel)
        msg.buttonClicked.connect(self.clearBtn)

        msg.exec_()

    def clearBtn(self, i):
        if i.text() == 'OK':
            self.textEdit.clear()
        else:
            pass
    
    def magnify(self):
        global zoomCheck
        try:
            cursor = self.textEdit.textCursor()
            restore = cursor.position()
            zoomCheck += 1
            cursor.movePosition(11)
            self.textEdit.setTextCursor(cursor)
            cursorEnd = cursor.position()
            self.textEdit.setTextCursor(cursor)
            cursor.movePosition(1)
            self.textEdit.setTextCursor(cursor)
            while cursorEnd > cursor.position():
                cursor.movePosition(17, 1)
                self.textEdit.setTextCursor(cursor)
                formats = cursor.charFormat()
                formats.setFontPointSize(formats.fontPointSize() + 1)
                cursor.setCharFormat(formats)
                cursor.setPosition(cursor.position(), 0)


            cursor.setPosition(restore, 0)
        except:
            pass
        try:
            zoomFile = open("C:\Users\Burhan\AppData\Roaming\RTE\%s.txt"
                             % name.split('/')[-1], 'r+')
            x = zoomFile.readlines()[0]
            zoomFile = open("C:\Users\Burhan\AppData\Roaming\RTE\%s.txt"
                             % name.split('/')[-1], 'w+')
            zoomFile.write(str(int(x) + 1))
        except:
            pass
 
    def demagnify(self):
        global zoomFile
        global zoomCheck
        try:
            cursor = self.textEdit.textCursor()
            restore = cursor.position()
            zoomCheck -= 1
            cursor.movePosition(11)
            self.textEdit.setTextCursor(cursor)
            cursorEnd = cursor.position()
            self.textEdit.setTextCursor(cursor)
            cursor.movePosition(1)
            self.textEdit.setTextCursor(cursor)
            while cursorEnd > cursor.position():
                cursor.movePosition(17, 1)
                self.textEdit.setTextCursor(cursor)
                formats = cursor.charFormat()
                formats.setFontPointSize(formats.fontPointSize() - 1)
                cursor.setCharFormat(formats)
                cursor.setPosition(cursor.position(), 0)
            cursor.setPosition(restore, 0)
        except:
            pass
        try:
            zoomFile = open("C:\Users\Burhan\AppData\Roaming\RTE\%s.txt"
                             % name.split('/')[-1], 'r+')
            x = zoomFile.readlines()[0]
            zoomFile = open("C:\Users\Burhan\AppData\Roaming\RTE\%s.txt"
                             % name.split('/')[-1], 'w+')
            zoomFile.write(str(int(x) - 1))
        except:
            pass

    def alRight(self):
        self.textEdit.setAlignment(QtCore.Qt.AlignRight)

    def alLeft(self):
        self.textEdit.setAlignment(QtCore.Qt.AlignLeft)

    def alCenter(self):
        self.textEdit.setAlignment(QtCore.Qt.AlignCenter)

    def alJustify(self):
        self.textEdit.setAlignment(QtCore.Qt.AlignJustify)

    def saveAsApp(self):
        name = QtGui.QFileDialog.getSaveFileName(self, 'save File')
        files = open(name, 'w')
        text = self.textEdit.toHtml()
        files.write(text)
        files.close()
        saveCheck = True
        windowTitle = name.split('/')[-1]
        self.setWindowTitle(windowTitle)

    def indent(self):
        try:
            cursor = self.textEdit.textCursor()
            textSelected = cursor.selectedText()
            if len(textSelected) == 0:
                cursor.insertText('\t')
            else:
                tab = QtCore.QString('\t')
                selStart = cursor.selectionStart()
                selEnd = cursor.selectionEnd()
                cursor.setPosition(selStart)
                self.textEdit.setTextCursor(cursor)
                cursor.insertText(tab)
                while selEnd > cursor.position():
                    cursor.movePosition(13)
                    cursor.movePosition(16)
                    self.textEdit.setTextCursor(cursor)
                    cursor.insertText(tab)

                cursor.setPosition(selStart)
                cursor.setPosition(selEnd, 1)
                self.textEdit.setTextCursor(cursor)
        except:
            pass

    def deindent(self):
        try:
            cursor = self.textEdit.textCursor()
            textSelected = cursor.selectedText()
            if len(textSelected) == 0:
                cursor.deleteChar()
            else:
                selStart = cursor.selectionStart()
                selEnd = cursor.selectionEnd()
                cursor.setPosition(selStart)
                self.textEdit.setTextCursor(cursor)
                cursor.deleteChar()
                while selEnd > cursor.position() + 4:
                    cursor.movePosition(13)
                    cursor.movePosition(16)
                    self.textEdit.setTextCursor(cursor)
                    cursor.deletePreviousChar()

                cursor.setPosition(selStart)
                cursor.setPosition(selEnd, 1)
                self.textEdit.setTextCursor(cursor)
        except:
            pass

    def numberList(self):
        cursor = self.textEdit.textCursor()
        if cursor.currentList() == None:
            cursor.createList(-4)
        else:
            cursor.setPosition(0)
            self.textEdit.setTextCursor(cursor)
            pyautogui.press('backspace')

    def bulletList(self):
        cursor = self.textEdit.textCursor()
        cursor.createList(-1)

    def changeFontTB(self, i):
        try:

                # The Cursor

            cursor = self.textEdit.textCursor()
            textSelected = cursor.selectedText()
            font = i
                 
            if len(textSelected) == 0:
                self.textEdit.setFontFamily(font)

            elif len(textSelected) > 0:

                restore = cursor.position()
                cursorEnd = cursor.selectionEnd()
                cursor.setPosition(cursor.selectionStart())
                self.textEdit.setTextCursor(cursor)
                while cursorEnd > cursor.position():
                    cursor.movePosition(17, 1)
                    self.textEdit.setTextCursor(cursor)
                    formats = cursor.charFormat()
                    formats.setFontFamily(font)
                    cursor.setCharFormat(formats)
                    cursor.setPosition(cursor.position(), 0)
                cursor.setPosition(restore)
        except:
            pass


    def changeSizeTB(self, i):
        global name
        global zoomFile
        global zoomCheck
        global windowTitle
        try:

                # The Cursor

            cursor = self.textEdit.textCursor()

                # Getting the cursor format

            formats = cursor.charFormat()
            textSelected = cursor.selectedText()
            if windowTitle == 'Rich Text Editor':

                    # Asking for font
                textSelected = cursor.selectedText()
                size = int(i[:-3])

                    # appliying it
                if len(textSelected) == 0:
                    self.textEdit.setFontPointSize(size)
                    if zoomCheck !=0:
                        self.textEdit.setFontPointSize(self.textEdit.fontPointSize()
                                + zoomCheck)
                elif len(textSelected) > 0:
                    restore = cursor.position()
                    cursorEnd = cursor.selectionEnd()
                    cursor.setPosition(cursor.selectionStart())
                    self.textEdit.setTextCursor(cursor)
                    while cursorEnd > cursor.position():
                        cursor.movePosition(17, 1)
                        self.textEdit.setTextCursor(cursor)
                        formats = cursor.charFormat()
                        formats.setFontPointSize(size)
                        formats.setFontPointSize(formats.fontPointSize() + zoomCheck)
                        cursor.setCharFormat(formats)
                        cursor.setPosition(cursor.position(), 0)
                    cursor.setPosition(restore)
                    
            else:
                print i
                zoomFile = \
                zoomFile = open("C:\Users\Burhan\AppData\Roaming\RTE\%s.txt"
                             % name.split('/')[-1], 'r+')
                zoomFile.seek(0)
                try:
                    x = int(zoomFile.readlines()[0])
                except:
                    pass
                size = int(i[:-3])
                zoomFile.close()

                if len(textSelected) == 0:
                    self.textEdit.setFontPointSize(size)
                    if x !=0:
                        self.textEdit.setFontPointSize(self.textEdit.fontPointSize()
                                + x)
                elif len(textSelected) > 1000:
                    restore = cursor.position()
                    cursorEnd = cursor.selectionEnd()
                    cursor.setPosition(cursor.selectionStart())
                    self.textEdit.setTextCursor(cursor)
                    while cursorEnd > cursor.position():
                        cursor.movePosition(17, 1)
                        self.textEdit.setTextCursor(cursor)
                        formats = cursor.charFormat()
                        formats.setFontPointSize(size)
                        formats.setFontPointSize(formats.fontPointSize() + x)
                        cursor.setCharFormat(formats)
                        cursor.setPosition(cursor.position(), 0)
                    cursor.setPosition(restore)


        except:
            pass

    def resetView(self):
        global zoomCheck
        if windowTitle == 'Rich Text Editor':
            if zoomCheck > 0:
                cursor = self.textEdit.textCursor()
                restore = cursor.position()
                cursor.movePosition(11)
                self.textEdit.setTextCursor(cursor)
                cursorEnd = cursor.position()
                self.textEdit.setTextCursor(cursor)
                cursor.movePosition(1)
                self.textEdit.setTextCursor(cursor)
                while cursorEnd > cursor.position():
                    cursor.movePosition(17, 1)
                    self.textEdit.setTextCursor(cursor)
                    formats = cursor.charFormat()
                    formats.setFontPointSize(formats.fontPointSize()
                            - zoomCheck)
                    cursor.setCharFormat(formats)
                    cursor.setPosition(cursor.position(), 0)
                cursor.setPosition(restore, 0)
                zoomCheck = 0
            elif zoomCheck < 0:
                cursor = self.textEdit.textCursor()
                restore = cursor.position()
                cursor.movePosition(11)
                self.textEdit.setTextCursor(cursor)
                cursorEnd = cursor.position()
                self.textEdit.setTextCursor(cursor)
                cursor.movePosition(1)
                self.textEdit.setTextCursor(cursor)
                while cursorEnd > cursor.position():
                    cursor.movePosition(17, 1)
                    self.textEdit.setTextCursor(cursor)
                    formats = cursor.charFormat()
                    formats.setFontPointSize(formats.fontPointSize()
                            - zoomCheck)
                    cursor.setCharFormat(formats)
                    cursor.setPosition(cursor.position(), 0)
                cursor.setPosition(restore, 0)
                zoomCheck = 0
            elif zoomCheck == 0:
                pass
        else:
            zoomFile = open("C:\Users\Burhan\AppData\Roaming\RTE\%s.txt"
                             % name.split('/')[-1], 'r+')
            zoomFile.seek(0)
            x = int(zoomFile.readlines()[0])
            if x > 0:
                cursor = self.textEdit.textCursor()
                restore = cursor.position()
                cursor.movePosition(11)
                self.textEdit.setTextCursor(cursor)
                cursorEnd = cursor.position()
                self.textEdit.setTextCursor(cursor)
                cursor.movePosition(1)
                self.textEdit.setTextCursor(cursor)
                while cursorEnd > cursor.position():
                    cursor.movePosition(17, 1)
                    self.textEdit.setTextCursor(cursor)
                    formats = cursor.charFormat()
                    formats.setFontPointSize(formats.fontPointSize()
                            - x)
                    cursor.setCharFormat(formats)
                    cursor.setPosition(cursor.position(), 0)
                cursor.setPosition(restore, 0)
                zoomFile.close()
                zoomFile = \
                    open("C:\Users\Burhan\AppData\Roaming\RTE\%s.txt"
                         % name.split('/')[-1], 'w+')
                zoomFile.write('0')
                zoomFile.close()
            elif zoomCheck < 0:
                cursor = self.textEdit.textCursor()
                restore = cursor.position()
                cursor.movePosition(11)
                self.textEdit.setTextCursor(cursor)
                cursorEnd = cursor.position()
                self.textEdit.setTextCursor(cursor)
                cursor.movePosition(1)
                self.textEdit.setTextCursor(cursor)
                while cursorEnd > cursor.position():
                    cursor.movePosition(17, 1)
                    self.textEdit.setTextCursor(cursor)
                    formats = cursor.charFormat()
                    formats.setFontPointSize(formats.fontPointSize()
                            - zoomCheck)
                    cursor.setCharFormat(formats)
                    cursor.setPosition(cursor.position(), 0)
                cursor.setPosition(restore, 0)
                zoomFile.close()
                zoomFile = \
                    open("C:\Users\Burhan\AppData\Roaming\RTE\%s.txt"
                         % name.split('/')[-1], 'w+')
                zoomFile.write('0')
                zoomFile.close()
                cursor.setPosition(restore, 0)


def run():
    app = QtGui.QApplication(sys.argv)
    GUI = Window()
    sys.exit(app.exec_())


run()
